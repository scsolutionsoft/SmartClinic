@echo off
setlocal
cd /d "C:\Program Files\SmartClinic\CardReader"
if not exist "SmartClinic.CardReader.Bridge.exe" (
  echo SmartClinic.CardReader.Bridge.exe not found.
  echo Copy the compiled executable into this folder first.
  pause
  exit /b 1
)
start "SmartClinic Card Reader Bridge" "SmartClinic.CardReader.Bridge.exe"
