@echo off
setlocal

echo SmartClinic Card Reader Bridge Installer

echo This package is intended for distribution with the SmartClinic system.
echo If you have the compiled bridge executable, copy it into this folder before running.
echo.
echo Installation target: C:\Program Files\SmartClinic\CardReader
if not exist "C:\Program Files\SmartClinic\CardReader" mkdir "C:\Program Files\SmartClinic\CardReader"
echo.
echo Copy your compiled SmartClinic.CardReader.Bridge.exe into the installation folder.
echo Then run start-bridge.bat to launch the bridge service.
pause
